# ARMWorkshop
1. EmptyTemplate - https://github.com/mifurm/ARMWorkshop/blob/master/emptytemplate.json
2. Basic VM - https://github.com/mifurm/ARMWorkshop/tree/master/2.SampleVM
